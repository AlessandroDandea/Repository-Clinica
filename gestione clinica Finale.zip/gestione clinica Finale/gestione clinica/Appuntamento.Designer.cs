﻿
namespace gestione_clinica
{
    partial class Appuntamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.ckBoxMedico = new System.Windows.Forms.CheckBox();
            this.ckBoxPaziente = new System.Windows.Forms.CheckBox();
            this.ckBoxData = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.cmbMedico = new System.Windows.Forms.ComboBox();
            this.cmbPaziente = new System.Windows.Forms.ComboBox();
            this.dTPicker = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvAppuntamenti = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAppuntamenti)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Maroon;
            this.panel1.Controls.Add(this.ckBoxMedico);
            this.panel1.Controls.Add(this.ckBoxPaziente);
            this.panel1.Controls.Add(this.ckBoxData);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.cmbMedico);
            this.panel1.Controls.Add(this.cmbPaziente);
            this.panel1.Controls.Add(this.dTPicker);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 100);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // ckBoxMedico
            // 
            this.ckBoxMedico.AutoSize = true;
            this.ckBoxMedico.Location = new System.Drawing.Point(416, 17);
            this.ckBoxMedico.Name = "ckBoxMedico";
            this.ckBoxMedico.Size = new System.Drawing.Size(22, 21);
            this.ckBoxMedico.TabIndex = 10;
            this.ckBoxMedico.UseVisualStyleBackColor = true;
            this.ckBoxMedico.CheckedChanged += new System.EventHandler(this.ckBoxMedico_CheckedChanged);
            // 
            // ckBoxPaziente
            // 
            this.ckBoxPaziente.AutoSize = true;
            this.ckBoxPaziente.Location = new System.Drawing.Point(277, 18);
            this.ckBoxPaziente.Name = "ckBoxPaziente";
            this.ckBoxPaziente.Size = new System.Drawing.Size(22, 21);
            this.ckBoxPaziente.TabIndex = 9;
            this.ckBoxPaziente.UseVisualStyleBackColor = true;
            this.ckBoxPaziente.CheckedChanged += new System.EventHandler(this.ckBoxPaziente_CheckedChanged);
            // 
            // ckBoxData
            // 
            this.ckBoxData.AutoSize = true;
            this.ckBoxData.Location = new System.Drawing.Point(63, 17);
            this.ckBoxData.Name = "ckBoxData";
            this.ckBoxData.Size = new System.Drawing.Size(22, 21);
            this.ckBoxData.TabIndex = 8;
            this.ckBoxData.UseVisualStyleBackColor = true;
            this.ckBoxData.CheckedChanged += new System.EventHandler(this.ckBoxData_CheckedChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(493, 53);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(125, 35);
            this.button2.TabIndex = 7;
            this.button2.Text = "Reset";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(493, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 35);
            this.button1.TabIndex = 6;
            this.button1.Text = "Filtra";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmbMedico
            // 
            this.cmbMedico.Enabled = false;
            this.cmbMedico.FormattingEnabled = true;
            this.cmbMedico.Location = new System.Drawing.Point(354, 45);
            this.cmbMedico.Name = "cmbMedico";
            this.cmbMedico.Size = new System.Drawing.Size(121, 28);
            this.cmbMedico.TabIndex = 5;
            // 
            // cmbPaziente
            // 
            this.cmbPaziente.Enabled = false;
            this.cmbPaziente.Location = new System.Drawing.Point(204, 45);
            this.cmbPaziente.Name = "cmbPaziente";
            this.cmbPaziente.Size = new System.Drawing.Size(121, 28);
            this.cmbPaziente.TabIndex = 4;
            // 
            // dTPicker
            // 
            this.dTPicker.Enabled = false;
            this.dTPicker.Location = new System.Drawing.Point(12, 47);
            this.dTPicker.Name = "dTPicker";
            this.dTPicker.Size = new System.Drawing.Size(167, 26);
            this.dTPicker.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Maroon;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(350, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Medico";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Maroon;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(200, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Paziente";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Maroon;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(13, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Data";
            // 
            // dgvAppuntamenti
            // 
            this.dgvAppuntamenti.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAppuntamenti.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAppuntamenti.Location = new System.Drawing.Point(0, 100);
            this.dgvAppuntamenti.Name = "dgvAppuntamenti";
            this.dgvAppuntamenti.RowHeadersVisible = false;
            this.dgvAppuntamenti.RowHeadersWidth = 62;
            this.dgvAppuntamenti.RowTemplate.Height = 28;
            this.dgvAppuntamenti.Size = new System.Drawing.Size(800, 350);
            this.dgvAppuntamenti.TabIndex = 1;
            this.dgvAppuntamenti.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAppuntamenti_CellContentClick);
            // 
            // Appuntamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvAppuntamenti);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Appuntamento";
            this.Text = "Appuntamento";
            this.Load += new System.EventHandler(this.Appuntamento_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAppuntamenti)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cmbMedico;
        private System.Windows.Forms.ComboBox cmbPaziente;
        private System.Windows.Forms.DateTimePicker dTPicker;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox ckBoxMedico;
        private System.Windows.Forms.CheckBox ckBoxPaziente;
        private System.Windows.Forms.CheckBox ckBoxData;
        private System.Windows.Forms.DataGridView dgvAppuntamenti;
    }
}