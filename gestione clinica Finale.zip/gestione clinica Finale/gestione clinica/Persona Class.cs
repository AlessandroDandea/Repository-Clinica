﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace gestione_clinica
{
    public class Persona_Class
    {

        public string Name { get; set; }

        public string Surname { get; set; }

        public string Id { get; set; }

        public Persona_Class(string name, string surname, string id)
        {

            Name = name;
            Surname = surname;
            Id = id;

        }


      

    }
}
