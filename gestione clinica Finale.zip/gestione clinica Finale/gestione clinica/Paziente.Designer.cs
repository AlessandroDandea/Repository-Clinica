﻿
namespace gestione_clinica
{
    partial class Paziente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvPaziente = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPaziente)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvPaziente
            // 
            this.dgvPaziente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPaziente.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPaziente.Location = new System.Drawing.Point(0, 0);
            this.dgvPaziente.Name = "dgvPaziente";
            this.dgvPaziente.RowHeadersWidth = 62;
            this.dgvPaziente.RowTemplate.Height = 28;
            this.dgvPaziente.Size = new System.Drawing.Size(800, 450);
            this.dgvPaziente.TabIndex = 0;
            this.dgvPaziente.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPaziente_CellContentClick);
            // 
            // Paziente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvPaziente);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Paziente";
            this.Text = "Paziente";
            this.Load += new System.EventHandler(this.Paziente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPaziente)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvPaziente;
    }
}