﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace gestione_clinica
{
    public partial class Specializazione : Form
    {
        public Specializazione()
        {
            InitializeComponent();
            dgvSpecializzazione.DataSource = CreateDataTable("specializzazioni.csv");
            dgvSpecializzazione.DefaultCellStyle.ForeColor = Color.White;
            dgvSpecializzazione.DefaultCellStyle.BackColor = Color.Red;
            dgvSpecializzazione.RowHeadersVisible = true;
            dgvSpecializzazione.SelectionMode = 0;
            


        }

        public DataTable CreateDataTable(string route)
        {
            DataTable source = new DataTable();
            string[] rows = File.ReadAllLines(route);
            if (rows.Length > 0)
            {

                string row = rows[0];
                string[] headerLabels = row.Split(';');


                foreach (string element in headerLabels)
                {

                    source.Columns.Add(new DataColumn(element));

                }


                for (int i = 1; i < rows.Length; i++)
                {

                    string[] data = rows[i].Split(';');
                    DataRow DR = source.NewRow();
                    int index = 0;


                    foreach (string element in headerLabels)
                    {

                        DR[element] = data[index++];

                    }

                    source.Rows.Add(DR);
                }



            }
            return source;
        }

        private void Specializazione_Load(object sender, EventArgs e)
        {
           
        }

        private void dgvSpecializzazione_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
