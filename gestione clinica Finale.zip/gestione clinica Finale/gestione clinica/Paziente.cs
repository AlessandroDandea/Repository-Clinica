﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace gestione_clinica
{
    public partial class Paziente : Form
    {
        public Paziente()
        {
            InitializeComponent();

            List<Paziente_class> Patients = File.ReadAllLines("pazienti.csv").Skip(1).Select(item => Paziente_class.FromCsv(item)).ToList();

            BindingList<Paziente_class> BindingPazienti = new BindingList<Paziente_class>(Patients);

            BindingSource sourcePazienti = new BindingSource(BindingPazienti, null);

            dgvPaziente.DataSource = sourcePazienti;
            dgvPaziente.DefaultCellStyle.ForeColor = Color.White;
            dgvPaziente.DefaultCellStyle.BackColor = Color.Red;
            dgvPaziente.RowHeadersVisible = true;
            dgvPaziente.SelectionMode = 0;
        }

        private void Paziente_Load(object sender, EventArgs e)
        {
           
        }

        private void dgvPaziente_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
