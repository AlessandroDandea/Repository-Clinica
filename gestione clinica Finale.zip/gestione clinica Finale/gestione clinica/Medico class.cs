﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace gestione_clinica
{
    public class Medico_CLass:Persona_Class  
    {
        public string Specialization { get; set; }


        public Medico_CLass(string name, string surname, string id, string specialization) : base(name, surname, id)
        {

            Specialization = specialization;

        }
        
        public static Medico_CLass FCSV(string line)
        {

            string[] values = line.Split(';');

            Medico_CLass elementoLista = new Medico_CLass("", "", "", "");

            elementoLista.Name = values[0];

            elementoLista.Surname = values[1];

            elementoLista.Id = values[3];

            elementoLista.Specialization = ConvertSpecialization(values[4]);

            return elementoLista;
        }
        public static string ConvertSpecialization(string el)
        {

            string[] lines = File.ReadAllLines("specializzazioni.csv");

            int index = Convert.ToInt32(el);

            string[] values = lines[index].Split(';');

            return values[1];

        }

    }
}
