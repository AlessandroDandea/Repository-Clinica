﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace gestione_clinica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loadform(new Medico());
        }

        private void btnPaziente_Click(object sender, EventArgs e)
        {
            loadform(new Paziente());
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }
        public void loadform(object Form)
        {

            if (this.MainPannel.Controls.Count > 0)
                this.MainPannel.Controls.RemoveAt(0);
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.MainPannel.Controls.Add(f);
            this.MainPannel.Tag = f;
            f.Show();
           
        }

        private void btnPatologie_Click(object sender, EventArgs e)
        {
            loadform(new Patologia());

        }

        private void btnSpecializazioni_Click(object sender, EventArgs e)
        {
            loadform(new Specializazione());

        }

        private void btnAppuntamenti_Click(object sender, EventArgs e)
        {
            loadform(new Appuntamento());

        }

        private void MainPannel_Paint(object sender, PaintEventArgs e)
        {

        }
        
        
    }
}
