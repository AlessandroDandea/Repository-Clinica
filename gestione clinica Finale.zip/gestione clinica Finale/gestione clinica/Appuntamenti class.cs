﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace gestione_clinica
{
    public class Appuntamenti_class
    {
        public string Doctor { get; set; }
        public string Patient { get; set; }
        public string Date { get; set; }


        public Appuntamenti_class(string nameDoctor, string namePatient, string dateAppointment)
        {
            Doctor = nameDoctor;
            Patient = namePatient;
            Date = dateAppointment;
        }


        public static Appuntamenti_class FromCsv(string line)
        {
            string[] values = line.Split(';');

            Appuntamenti_class ListElement = new Appuntamenti_class("", "", "");

            ListElement.Date = values[0];

            ListElement.Patient = ConvertPatient(Convert.ToInt32(values[1]));

            ListElement.Doctor = ConvertDoctor(Convert.ToInt32(values[2]) - 500);

            return ListElement;
        }
        public static string ConvertPatient(int index)
        {

            string[] lines = File.ReadAllLines("pazienti.csv");

            string[] values = lines[index].Split(';');

            return $"{values[0]} {values[1]}";

        }

        public static string ConvertDoctor(int index)
        {

            string[] lines = File.ReadAllLines("medici.csv");

            string[] values = lines[index].Split(';');

            return $"{values[0]} {values[1]}";

        }
    }
}
