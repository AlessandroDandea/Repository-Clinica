﻿
namespace gestione_clinica
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnAppuntamenti = new System.Windows.Forms.Button();
            this.btnPaziente = new System.Windows.Forms.Button();
            this.btnSpecializazioni = new System.Windows.Forms.Button();
            this.btnMedici = new System.Windows.Forms.Button();
            this.btnPatologie = new System.Windows.Forms.Button();
            this.MainPannel = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.btnAppuntamenti);
            this.panel1.Controls.Add(this.btnPaziente);
            this.panel1.Controls.Add(this.btnSpecializazioni);
            this.panel1.Controls.Add(this.btnMedici);
            this.panel1.Controls.Add(this.btnPatologie);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 450);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::gestione_clinica.Properties.Resources.pharmacy1;
            this.pictureBox6.Location = new System.Drawing.Point(39, 29);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(115, 111);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 11;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::gestione_clinica.Properties.Resources.appointment;
            this.pictureBox5.Location = new System.Drawing.Point(12, 351);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(35, 34);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 10;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::gestione_clinica.Properties.Resources.degrees;
            this.pictureBox4.Location = new System.Drawing.Point(12, 311);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(35, 34);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::gestione_clinica.Properties.Resources.illness__1_;
            this.pictureBox3.Location = new System.Drawing.Point(12, 271);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(35, 34);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::gestione_clinica.Properties.Resources.doctor;
            this.pictureBox2.Location = new System.Drawing.Point(12, 231);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(35, 34);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::gestione_clinica.Properties.Resources.illness;
            this.pictureBox1.Location = new System.Drawing.Point(12, 191);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(35, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // btnAppuntamenti
            // 
            this.btnAppuntamenti.BackColor = System.Drawing.Color.Red;
            this.btnAppuntamenti.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btnAppuntamenti.FlatAppearance.BorderSize = 0;
            this.btnAppuntamenti.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnAppuntamenti.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAppuntamenti.Font = new System.Drawing.Font("Montserrat", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppuntamenti.ForeColor = System.Drawing.Color.White;
            this.btnAppuntamenti.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAppuntamenti.Location = new System.Drawing.Point(53, 351);
            this.btnAppuntamenti.Name = "btnAppuntamenti";
            this.btnAppuntamenti.Size = new System.Drawing.Size(152, 34);
            this.btnAppuntamenti.TabIndex = 6;
            this.btnAppuntamenti.Text = "Appuntamenti";
            this.btnAppuntamenti.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAppuntamenti.UseVisualStyleBackColor = false;
            this.btnAppuntamenti.Click += new System.EventHandler(this.btnAppuntamenti_Click);
            // 
            // btnPaziente
            // 
            this.btnPaziente.BackColor = System.Drawing.Color.Red;
            this.btnPaziente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPaziente.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btnPaziente.FlatAppearance.BorderSize = 0;
            this.btnPaziente.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnPaziente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPaziente.Font = new System.Drawing.Font("Montserrat", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaziente.ForeColor = System.Drawing.Color.White;
            this.btnPaziente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPaziente.Location = new System.Drawing.Point(53, 191);
            this.btnPaziente.Name = "btnPaziente";
            this.btnPaziente.Size = new System.Drawing.Size(152, 34);
            this.btnPaziente.TabIndex = 2;
            this.btnPaziente.Text = "Paziente";
            this.btnPaziente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPaziente.UseVisualStyleBackColor = false;
            this.btnPaziente.Click += new System.EventHandler(this.btnPaziente_Click);
            // 
            // btnSpecializazioni
            // 
            this.btnSpecializazioni.BackColor = System.Drawing.Color.Red;
            this.btnSpecializazioni.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btnSpecializazioni.FlatAppearance.BorderSize = 0;
            this.btnSpecializazioni.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnSpecializazioni.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSpecializazioni.Font = new System.Drawing.Font("Montserrat", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpecializazioni.ForeColor = System.Drawing.Color.White;
            this.btnSpecializazioni.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSpecializazioni.Location = new System.Drawing.Point(53, 311);
            this.btnSpecializazioni.Name = "btnSpecializazioni";
            this.btnSpecializazioni.Size = new System.Drawing.Size(152, 34);
            this.btnSpecializazioni.TabIndex = 5;
            this.btnSpecializazioni.Text = "Specializazioni";
            this.btnSpecializazioni.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSpecializazioni.UseVisualStyleBackColor = false;
            this.btnSpecializazioni.Click += new System.EventHandler(this.btnSpecializazioni_Click);
            // 
            // btnMedici
            // 
            this.btnMedici.BackColor = System.Drawing.Color.Red;
            this.btnMedici.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btnMedici.FlatAppearance.BorderSize = 0;
            this.btnMedici.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnMedici.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedici.Font = new System.Drawing.Font("Montserrat", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedici.ForeColor = System.Drawing.Color.White;
            this.btnMedici.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMedici.Location = new System.Drawing.Point(53, 231);
            this.btnMedici.Name = "btnMedici";
            this.btnMedici.Size = new System.Drawing.Size(152, 34);
            this.btnMedici.TabIndex = 3;
            this.btnMedici.Text = "Medici";
            this.btnMedici.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMedici.UseVisualStyleBackColor = false;
            this.btnMedici.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnPatologie
            // 
            this.btnPatologie.BackColor = System.Drawing.Color.Red;
            this.btnPatologie.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btnPatologie.FlatAppearance.BorderSize = 0;
            this.btnPatologie.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnPatologie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPatologie.Font = new System.Drawing.Font("Montserrat", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatologie.ForeColor = System.Drawing.Color.White;
            this.btnPatologie.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPatologie.Location = new System.Drawing.Point(53, 271);
            this.btnPatologie.Name = "btnPatologie";
            this.btnPatologie.Size = new System.Drawing.Size(152, 34);
            this.btnPatologie.TabIndex = 4;
            this.btnPatologie.TabStop = false;
            this.btnPatologie.Text = "Patologie";
            this.btnPatologie.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPatologie.UseVisualStyleBackColor = false;
            this.btnPatologie.Click += new System.EventHandler(this.btnPatologie_Click);
            // 
            // MainPannel
            // 
            this.MainPannel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainPannel.Location = new System.Drawing.Point(200, 0);
            this.MainPannel.Name = "MainPannel";
            this.MainPannel.Size = new System.Drawing.Size(600, 450);
            this.MainPannel.TabIndex = 1;
            this.MainPannel.Paint += new System.Windows.Forms.PaintEventHandler(this.MainPannel_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.MainPannel);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Gestione clinica";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAppuntamenti;
        private System.Windows.Forms.Button btnPaziente;
        private System.Windows.Forms.Button btnSpecializazioni;
        private System.Windows.Forms.Button btnMedici;
        private System.Windows.Forms.Button btnPatologie;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel MainPannel;
    }
}

