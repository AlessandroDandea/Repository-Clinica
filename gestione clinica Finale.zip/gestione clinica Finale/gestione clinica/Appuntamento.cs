﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace gestione_clinica
{
    public partial class Appuntamento : Form
    {



        public Appuntamento()
        {
            InitializeComponent();

            List<Appuntamenti_class>  Appuntamenti = GeneraAppuntamenti();
            foreach (Appuntamenti_class appuntamento in Appuntamenti)
            {
                cmbMedico.Items.Add(appuntamento.Doctor);
                cmbPaziente.Items.Add(appuntamento.Patient);
            }

            dTPicker.Format = DateTimePickerFormat.Custom;
            dTPicker.CustomFormat = "yyyy-MM-dd";
            dgvAppuntamenti.DefaultCellStyle.ForeColor = Color.White;
            dgvAppuntamenti.DefaultCellStyle.BackColor = Color.Red;
            dgvAppuntamenti.RowHeadersVisible = true;
            dgvAppuntamenti.SelectionMode = 0;

        }

        public  List<Appuntamenti_class> GeneraAppuntamenti()
        {
            List<Appuntamenti_class> Appuntamenti = File.ReadAllLines("appuntamenti.csv").Skip(1).Select(item => Appuntamenti_class.FromCsv(item)).ToList();
            BindingList<Appuntamenti_class> BindingAppuntamenti = new BindingList<Appuntamenti_class>(Appuntamenti);
            BindingSource sourceAppuntamenti = new BindingSource(BindingAppuntamenti, null);
            dgvAppuntamenti.DataSource = sourceAppuntamenti;
            return Appuntamenti;
        }


        private void Appuntamento_Load(object sender, EventArgs e)
        {
         
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        public void button1_Click(object sender, EventArgs e)
        {
            List<Appuntamenti_class> Appuntamenti = GeneraAppuntamenti();
            List<Appuntamenti_class> Risultati = new List<Appuntamenti_class>();
            Risultati = Appuntamenti;
            if (ckBoxMedico.Checked == true)
            {
                Risultati = Risultati.Where(range => range.Doctor == (string)cmbMedico.SelectedItem).ToList();
            }
            if (ckBoxPaziente.Checked == true)
            {
                Risultati = Risultati.Where(range => range.Patient == (string)cmbPaziente.SelectedItem).ToList();
            }
            if (ckBoxData.Checked == true)
            {
                Risultati = Risultati.Where(range => range.Date.Split(' ')[0] == dTPicker.Text).ToList();
            }
            BindingList<Appuntamenti_class> BindingAppuntamenti = new BindingList<Appuntamenti_class>(Risultati);
            BindingSource sourceAppuntamenti = new BindingSource(BindingAppuntamenti, null);
            dgvAppuntamenti.DataSource = sourceAppuntamenti;
        }


        public void ckBoxMedico_CheckedChanged(object sender, EventArgs e)
        {
            cmbMedico.Enabled = !cmbMedico.Enabled;
        }

        public void ckBoxPaziente_CheckedChanged(object sender, EventArgs e)
        {
            cmbPaziente.Enabled = !cmbPaziente.Enabled;
        }

        public void ckBoxData_CheckedChanged(object sender, EventArgs e)
        {
            dTPicker.Enabled = !dTPicker.Enabled;
        }

        public void button2_Click(object sender, EventArgs e)
        {
            GeneraAppuntamenti();
            ckBoxData.Checked = false;
            ckBoxMedico.Checked = false;
            ckBoxPaziente.Checked = false;
        }

        private void dgvAppuntamenti_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
