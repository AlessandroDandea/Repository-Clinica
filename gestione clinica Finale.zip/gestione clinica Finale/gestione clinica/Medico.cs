﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace gestione_clinica
{
    public partial class Medico : Form
    {
        public Medico()
        {
            InitializeComponent();

            List<Medico_CLass> Doctors = File.ReadAllLines("medici.csv").Skip(1).Select(item => Medico_CLass.FCSV(item)).ToList();

            BindingList<Medico_CLass> BindingDoctors = new BindingList<Medico_CLass>(Doctors);

            BindingSource sourceDoctors = new BindingSource(BindingDoctors, null);

            dgvMedici.DataSource = sourceDoctors;
            dgvMedici.DefaultCellStyle.ForeColor = Color.White;
            dgvMedici.DefaultCellStyle.BackColor = Color.Red;
            dgvMedici.RowHeadersVisible = true;
            dgvMedici.SelectionMode = 0;
        }

        private void Medico_Load(object sender, EventArgs e)
        {
           
        }

        private void dgvMedici_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
