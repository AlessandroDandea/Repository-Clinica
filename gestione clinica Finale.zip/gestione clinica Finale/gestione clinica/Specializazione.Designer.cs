﻿
namespace gestione_clinica
{
    partial class Specializazione
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvSpecializzazione = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSpecializzazione)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvSpecializzazione
            // 
            this.dgvSpecializzazione.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSpecializzazione.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSpecializzazione.Location = new System.Drawing.Point(0, 0);
            this.dgvSpecializzazione.Name = "dgvSpecializzazione";
            this.dgvSpecializzazione.RowHeadersWidth = 62;
            this.dgvSpecializzazione.RowTemplate.Height = 28;
            this.dgvSpecializzazione.Size = new System.Drawing.Size(800, 450);
            this.dgvSpecializzazione.TabIndex = 0;
            this.dgvSpecializzazione.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSpecializzazione_CellContentClick);
            // 
            // Specializazione
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvSpecializzazione);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Specializazione";
            this.Text = "Specializazione";
            this.Load += new System.EventHandler(this.Specializazione_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSpecializzazione)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvSpecializzazione;
    }
}