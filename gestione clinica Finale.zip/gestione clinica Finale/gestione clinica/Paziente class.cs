﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace gestione_clinica
{
    public class Paziente_class : Persona_Class
    {
        public string Pathology { get; set; }


        public Paziente_class(string name, string surname, string id, string pathology) : base(name, surname, id)
        {

            Pathology = pathology;

        }

        
        public static Paziente_class FromCsv(string line)
        {

            string[] values = line.Split(';');

            Paziente_class ListElement = new Paziente_class("", "", "", "");

            ListElement.Name = values[0];

            ListElement.Surname = values[1];

            ListElement.Id = values[3];

            ListElement.Pathology = ConvertPatologia(values[2]);

            return ListElement;

        }


        public static string ConvertPatologia(string el)
        {
            string[] lines = File.ReadAllLines("patologie.csv");

            int index = Convert.ToInt32(el);

            string[] values = lines[index].Split(';');

            return values[1];

        }

    }
}
